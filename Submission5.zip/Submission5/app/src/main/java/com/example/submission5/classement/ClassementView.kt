package com.example.submission5.classement

import com.example.submission5.model.Main

interface ClassementView{
    fun showClassement(data:List<Main>)
}