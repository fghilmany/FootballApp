package com.example.submission5

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.submission5.favorite.Favorite
import org.jetbrains.anko.AnkoContext

class FavoriteAdapter (private val favorite: List<Favorite>, private val listener:(Favorite)->Unit)
    :RecyclerView.Adapter<FavoriteViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, position: Int): FavoriteViewHolder {
        return FavoriteViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_match_item, parent, false))
    }

    override fun getItemCount(): Int = favorite.size

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        holder.bindItem(favorite[position], listener)
    }

}

class FavoriteViewHolder(view:View):RecyclerView.ViewHolder(view) {
    private  val homeTeamName : TextView = view.findViewById(R.id.tv_home_name)
    private val awayTeamName : TextView = view.findViewById(R.id.tv_away_name)
    private val scoreHome : TextView = view.findViewById(R.id.tv_home_score)
    private val scoreAway : TextView = view.findViewById(R.id.tv_away_score)
    private val matchDate : TextView = view.findViewById(R.id.tv_date_match)

    fun bindItem (favorite : Favorite, listener: (Favorite) -> Unit){
        homeTeamName.text = favorite.teamHomeName
        awayTeamName.text = favorite.teamAwayName
        scoreHome.text = favorite.teamHomeScore
        scoreAway.text = favorite.teamAwayScore
        matchDate.text = favorite.dateMatch

        itemView.setOnClickListener {
            listener(favorite)
        }

    }

}
