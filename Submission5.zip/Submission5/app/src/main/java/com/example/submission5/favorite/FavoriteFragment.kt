package com.example.submission5.favorite


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.submission5.FavoriteAdapter

import com.example.submission5.R
import com.example.submission5.helper.database
import com.example.submission5.match.MatchAdapter
import com.example.submission5.match.detail.DetailMatchActivity
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.find
import java.nio.file.Files.find

class FavoriteFragment : Fragment() {

    private var favorites : MutableList<Favorite> = mutableListOf()
    private lateinit var adapter: FavoriteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favorite, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val rvMatch = find<RecyclerView>(R.id.rv_favorite)
        rvMatch.layoutManager = LinearLayoutManager(activity)
        adapter = FavoriteAdapter(favorites){
            context?.startActivity<DetailMatchActivity>(
                "idMatch" to it.matchId,
                "nameHome" to it.teamHomeName,
                "nameAway" to it.teamAwayName)
            val toast = Toast.makeText(activity,it.teamHomeName + " vs " + it.teamAwayName, Toast.LENGTH_SHORT)
            toast.show()
        }

        rvMatch.adapter = adapter
        showFavorite()
    }

    override fun onResume(){
        super.onResume()
        showFavorite()
    }

    private fun showFavorite(){
        favorites.clear()
        context?.database?.use {
            val result = select (Favorite.TABLE_FAVORITE)
            val favorite = result.parseList(classParser<Favorite>())
            favorites.addAll(favorite)
            adapter.notifyDataSetChanged()
        }
    }


}
