package com.example.submission5.team

import com.example.submission5.model.Main

interface TeamView {
    fun listTeam(data:List<Main>)
}