package com.example.submission5.model

data class MainResponse (
    val leagues:List<Main>,
    val events:List<Main>,
    val table:List<Main>,
    val teams:List<Main>,
    val player:List<Main>,
    val event:List<Main>,
    val players:List<Main>)
