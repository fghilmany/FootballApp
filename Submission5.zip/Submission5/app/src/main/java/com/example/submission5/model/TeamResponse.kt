package com.example.submission5.model

data class TeamResponse (
    val teams:List<Team>
)