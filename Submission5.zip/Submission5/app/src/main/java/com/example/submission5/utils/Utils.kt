package com.example.submission5.utils

import android.view.View

fun View.visible(){
    visibility = View.VISIBLE
}

fun View.invisivle(){
    visibility = View.INVISIBLE
}